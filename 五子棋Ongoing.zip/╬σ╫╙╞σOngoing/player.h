#pragma once
#include<iostream>
#include<string>
using namespace std;


class Player
{
public:
	void PutChess();
	static char PlayerX;
	static int PlayerY;
};

