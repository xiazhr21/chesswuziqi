#include "Referee.h"
#include "ChessBoard.h"
#include "player.h"
#include "player2.h"
#include "Computer.h"


//ģʽ1--�˻���ս
void Referee::Mode1()
{
	ChessBoard Board1;
	Board1.InitialBoardValue();
	int Mode1Choose;
	cout << "��ѡ���Ⱥ���" << endl;
	cout << " 1-----�������" << endl;
	cout << " 2-----��������" << endl;
	cin >> Mode1Choose;
	cout << Mode1Choose;
	system("cls");

	switch (Mode1Choose)
	{
	case 1:
		Board1.ChessBoardOutput();
		Player Player1;//�������1
		Computer Computer1;//�����������1
		cout << "-----�˻���սģʽ-----" << endl;
		cout << "-------�������-------" << endl;
		for (int l = 0; l < 112; l++)
		{
			if (VicNum == 0)
			{
				Referee::BackMenu();
				Player1.PutChess();//�������
				if (Player1.PlayerX == 'X')
				{
					VicNum = 3;
					cout << VicNum << endl;
					break;
				}
				Board1.BoardValueChange();//���̸�ֵ�ı�

				system("cls");
				Referee::VictoryJudgment1(Board1);
				Referee::VictoryJudgment2(Board1);
				Referee::VictoryJudgment3(Board1);
				Referee::VictoryJudgment4(Board1);
				

				if (VicNum == 0)
				{
					Computer1.FindMax();
					Computer1.PutChess();
					
					Referee::PCVictoryJudgment1(Board1);
					Referee::PCVictoryJudgment2(Board1);
					Referee::PCVictoryJudgment3(Board1);
					Referee::PCVictoryJudgment4(Board1);
					
					Computer1.RefreshMax();
					Board1.Board[ChessBoard::BoardX][ChessBoard::BoardY] = 21;
					Board1.Board[Computer::MaxY][Computer::MaxX] = 11;
					Board1.ChessBoardOutput();
					Board1.Board[ChessBoard::BoardX][ChessBoard::BoardY] = 20;
					Board1.Board[Computer::MaxY][Computer::MaxX] = 10;
				}

				if (VicNum == 1)
				{
					cout << "-----�˻���սģʽ-----" << endl;
					cout << "-------�������-------" << endl;
					Board1.ChessBoardOutput();
				}
			}
		}
		if (VicNum == 3)
		{
			system("cls");
			VicNum = 0;
			Referee Referee1;
			Referee1.Introduction();
			Referee1.StartMenu();
			Referee1.Modejudgment();
		}
		break;
	case 2:
		Player Player2;//�������1
		Computer Computer2;//�����������1

		Computer2.FirstPut();
		Computer2.PutChess();
		Board1.ChessBoardOutput();


		for (int l = 0; l < 112; l++)
		{
			Referee::BackMenu();
			if (VicNum == 0)
			{
				Player2.PutChess();//�������
				if (Player2.PlayerX == 'X')
				{
					VicNum = 3;
					cout << VicNum << endl;
					break;
				}
				Board1.BoardValueChange();//���̸�ֵ�ı�

				system("cls");
				Referee::VictoryJudgment1(Board1);
				Referee::VictoryJudgment2(Board1);
				Referee::VictoryJudgment3(Board1);
				Referee::VictoryJudgment4(Board1);

				if (VicNum == 0)
				{
					Computer2.FindMax();
					Computer2.PutChess();
					
					Referee::PCVictoryJudgment1(Board1);
					Referee::PCVictoryJudgment2(Board1);
					Referee::PCVictoryJudgment3(Board1);
					Referee::PCVictoryJudgment4(Board1);

					Computer2.RefreshMax();
					Board1.Board[ChessBoard::BoardX][ChessBoard::BoardY] = 21;
					Board1.Board[Computer::MaxY][Computer::MaxX] = 11;
					Board1.ChessBoardOutput();
					Board1.Board[ChessBoard::BoardX][ChessBoard::BoardY] = 20;
					Board1.Board[Computer::MaxY][Computer::MaxX] = 10;
				}

				if (VicNum == 1)
				{
					cout << "-----�˻���սģʽ-----" << endl;
					cout << "-------��������-------" << endl;
					Board1.ChessBoardOutput();
					break;
				}
			}
		}
		if (VicNum == 3)
		{
			system("cls");
			VicNum = 0;
			Referee Referee1;
			Referee1.Introduction();
			Referee1.StartMenu();
			Referee1.Modejudgment();
		}
		break;
	default:
		break;
	}
}

//ģʽ2--���˶�ս
void Referee::Mode2()
{
	ChessBoard Board1;
	Board1.InitialBoardValue();
	Board1.ChessBoardOutput();
	Player Player1;
	Player2 Player2;

	cout << "-----���˶�սģʽ-----" << endl;
	for(int l = 0; l < 112; l++)
	{
		Referee::BackMenu();
		if (VicNum == 0)
		{
			
			Player1.PutChess();
			if (Player1.PlayerX == 'X')
			{
				VicNum = 3;
				cout << VicNum << endl;
				break;
			}
			Board1.BoardValueChange();
			system("cls");
			Board1.ChessBoardOutput();
			Referee::VictoryJudgment1(Board1);
			Referee::VictoryJudgment2(Board1);
			Referee::VictoryJudgment3(Board1);
			Referee::VictoryJudgment4(Board1);

			if (VicNum == 0)
			{
				Referee::BackMenu();
				Player2.PutChess();
				if (Player2.PlayerX == 'X')
				{
					VicNum = 3;
					cout << VicNum << endl;
					break;
				}
				Board1.BoardValueChangeForPlayer2();
				system("cls");
				Referee::P2VictoryJudgment1(Board1);
				Referee::P2VictoryJudgment2(Board1);
				Referee::P2VictoryJudgment3(Board1);
				Referee::P2VictoryJudgment4(Board1);
				Board1.ChessBoardOutput();
			}
			
			

			if (VicNum == 1)
			{
				cout << "-----�˻���սģʽ-----" << endl;
				cout << "-------���˶�ս-------" << endl;
				Board1.ChessBoardOutput();
				break;
			}
		}
	}
	if (VicNum == 3)
	{
		system("cls");
		VicNum = 0;
		Referee Referee1;
		Referee1.Introduction();
		Referee1.StartMenu();
		Referee1.Modejudgment();
	}
}




//ģʽ3--�˳���Ϸ
int Referee::Mode3()
{
	cout << "-----�����˳���Ϸ-----" << endl;
	cout << "-----��ӭ�´�ʹ��-----" << endl;
	return 0;
}
//���1���ʤ��
int Referee::ModeVic()
{
	cout << "!!!!!!��ϲ��(���1)�ѻ�ʤ!!!!!!" << endl;
	return 0;
}
//���2���ʤ��
int Referee::ModeVicP2()
{
	cout << "******��ϲ��(���2)�ѻ�ʤ******" << endl;
	return 0;
}
//������һ��ʤ��
int Referee::ModeVicComputer()
{
	cout << "!!!!!���Ѿ������Դ��!!!!!" << endl;
	return 0;
}
//�ص����˵�
void Referee::BackMenu()
{
	cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!�����괦����X�������괦����1----�ɷ������˵�" << endl;
}