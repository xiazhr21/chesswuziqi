#pragma once
#include<iostream>
#include "player.h"
using namespace std;



class Player2 
{
public:
	void PutChess();
	static char PlayerX;
	static int PlayerY;
};
