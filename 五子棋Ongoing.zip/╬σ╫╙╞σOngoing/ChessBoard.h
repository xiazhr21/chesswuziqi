#pragma once
#include<iostream>
using namespace std;


class ChessBoard
{
public:
	void ChessBoardOutput();
	void InitialBoardValue();
	void BoardValueChange();
	void BoardValueChangeForPlayer2();

	static int Board[16][16];
	static int BoardX;
	static int BoardY;
};
