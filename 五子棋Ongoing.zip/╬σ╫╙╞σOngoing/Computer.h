#pragma once
#include<iostream>
using namespace std;




class Computer
{
public:
	void FindMax();
	void RefreshMax();
	void PutChess();
	void FirstPut();
	static int MaxX;
	static int MaxY;
	static int  Max;
};