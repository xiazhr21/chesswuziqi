#include "ChessBoard.h"
#include<string>
#include "player.h"



//����������ֵ����ͼ������ĺ���
void ChessBoard::ChessBoardOutput()
{
	char firstline;
	Board[0][0] = 0;
	if (Board[0][0] == 0)
	{
		cout << "  ";
	}
	for (int k = 1; k < 16; k++)
	{
		firstline = '@' + k;
		cout << " " << firstline;
	}
	cout << endl;

	for (int i = 1; i < 16; i++)
	{
		if (i < 10)
		{
			cout << " ";
		}
		cout << i;
		for (int j = 1; j < 16; j++)
		{
			//cout << Board[i][j];
			switch (Board[i][j] % 100)
			{
			case 1:
				cout << "�� ";
				break;
			case 2:
				cout << "�� ";
				break;
			case 3:
				cout << "��";
				break;
			case 4:
				cout << "�� ";
				break;
			case 5:
				cout << "�� ";
				break;
			case 6:
				cout << "��";
				break;
			case 7:
				cout << "�� ";
				break;
			case 8:
				cout << "�� ";
				break;
			case 9:
				cout << "��";
				break;
			case 10:
				cout << "��";
				break;
			case 11:
				cout << "��";
				break;
			case 20:
				cout << "��";
				break;
			case 21:
				cout << "��";
				break;
			}
		}
		cout << endl;
	}
}