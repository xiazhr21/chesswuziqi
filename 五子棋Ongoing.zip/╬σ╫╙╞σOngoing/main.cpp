#include<iostream>
#include "ChessBoard.h"
#include "Referee.h"
#include "player.h"
using namespace std;
 
 
int main() {

	system("color 0");

	Referee Referee1;
	Referee1.Introduction();
	Referee1.StartMenu();
	Referee1.Modejudgment();

	system("pause");
	return 0;
}