#include "ChessBoard.h"
#include<string>
#include "player.h"
#include "player2.h"


//�����������̸�ֵ�ĸı亯��
//����Ϊ���ģ�����AI������ʵ��
//�˴����ø�ֵ��

void ChessBoard::BoardValueChange()
{

	BoardX = Player::PlayerY;
	BoardY = int(Player::PlayerX) - 64;

	Board[BoardX][BoardY] = 20;
	Board[BoardX][BoardY + 1] = 800 + Board[BoardX][BoardY + 1];

	for (int i = BoardX - 1; i < BoardX + 2; i++)
	{
		for (int j = BoardY - 1; j < BoardY + 2; j++)
		{
			int k = abs(i - j);
			if (i == BoardX && j == BoardY)
			{
				break;
			}
			else if (Board[i][j] == 20 || Board[i][j] == 10)
			{
				break;
			}
			else if (k == 1)
			{
				Board[i][j] = 800 + Board[i][j];
			}
			else
			{
				Board[i][j] = 1000 + Board[i][j];
			}
		}
	}
}

void ChessBoard::BoardValueChangeForPlayer2()
{
	BoardX = Player2::PlayerY;
	BoardY = int(Player2::PlayerX) - 64;

	Board[BoardX][BoardY] = 10;
}