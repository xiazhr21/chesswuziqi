#include "Referee.h"
#include "ChessBoard.h"
#include "player.h"
#include "Computer.h"

//���1�Ƿ�ʤ���ж�����
//ˮƽ����������������ж�
void Referee::VictoryJudgment1(ChessBoard Board1)
{
	for (int i = 1; i < 15; i++)
	{
		int num1 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[i][j] == 20)
			{
				num1++;
			}
		
		}
		if (num1 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[num1];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
					if (Board1.Board[i][k] == 20)
				{
					p[p1] = k;
					p1++;
				}
			}

		
			for (int m = 0; m < num1 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVic();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
		delete[]p;
	
		}
	}
}

//��ֱ����������������ж�
void Referee::VictoryJudgment2(ChessBoard Board1)
{

	for (int i = 1; i < 15; i++)
	{
		int Num2 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[j][i] == 20)
			{
				Num2++;
			}

		}
	
		if (Num2 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[Num2];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
				if (Board1.Board[k][i] == 20)
				{
					p[p1] = k;
					p1++;
				}
			}


			for (int m = 0; m < Num2 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVic();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
			delete[]p;
		}
	}
}

//б��������½�����������
void Referee::VictoryJudgment3(ChessBoard Board1)
{
	int Num3 =0 ;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j]==20)
			{
				Num3++;
			}
		}
	}
	if (Num3 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
				for (int m = 1; m < 15;m++)
				{
					if (Board1.Board[k][m] == 20)
					{
						int couter1 = 1;
						for (int couter2 = 1;couter2 < 5;couter2++)
						{
							if (k + couter2 < 15 && m + couter2 < 15)
							{
								if (Board1.Board[k + couter2][m + couter2] == 20)
								{
									couter1++;
								}
								else
								{
									break;
								}
							}
							else
							{
								break;
							}
						}
						if (couter1 == 5)
						{
							couter3 = 1;
							break;
						}
						else
						{
							continue;
						}
					}
					else
					{
						continue;
					}

				}
				if (couter3 == 1)
				{
					Referee::ModeVic();
					Referee::VicNum = 1;
					break;
				}
		}	
	}
}
//б����������½�����������
void Referee::VictoryJudgment4(ChessBoard Board1)
{
	int Num4 = 0;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j] == 20)
			{
				Num4++;
			}
		}
	}

	if (Num4 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
			for (int m = 1; m < 15;m++)
			{
				if (Board1.Board[k][m] == 20)
				{
					int couter1 = 1;
					for (int couter2 = 1;couter2 < 5;couter2++)
					{
						if (k + couter2 < 15 && m - couter2 > 0)
						{
							if (Board1.Board[k + couter2][m - couter2] == 20)
							{
								couter1++;
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
					if (couter1 == 5)
					{
						couter3 = 1;
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}

			}
			if (couter3 == 1)
			{
				Referee::ModeVic();
				Referee::VicNum = 1;
				break;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------



//���2�Ƿ�ʤ���ж�����
//ˮƽ����������������ж�
void Referee::P2VictoryJudgment1(ChessBoard Board1)
{
	for (int i = 1; i < 15; i++)
	{
		int num1 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				num1++;
			}

		}
		if (num1 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[num1];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
				if (Board1.Board[i][k] == 10)
				{
					p[p1] = k;
					p1++;
				}
			}


			for (int m = 0; m < num1 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVicP2();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
			delete[]p;

		}
	}
}

//��ֱ����������������ж�
void Referee::P2VictoryJudgment2(ChessBoard Board1)
{

	for (int i = 1; i < 15; i++)
	{
		int Num2 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[j][i] == 10)
			{
				Num2++;
			}

		}

		if (Num2 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[Num2];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
				if (Board1.Board[k][i] == 10)
				{
					p[p1] = k;
					p1++;
				}
			}


			for (int m = 0; m < Num2 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVicP2();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
			delete[]p;
		}
	}
}

//б��������½�����������
void Referee::P2VictoryJudgment3(ChessBoard Board1)
{
	int Num3 = 0;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				Num3++;
			}
		}
	}
	if (Num3 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
			for (int m = 1; m < 15;m++)
			{
				if (Board1.Board[k][m] == 10)
				{
					int couter1 = 1;
					for (int couter2 = 1;couter2 < 5;couter2++)
					{
						if (k + couter2 < 15 && m + couter2 < 15)
						{
							if (Board1.Board[k + couter2][m + couter2] == 10)
							{
								couter1++;
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
					if (couter1 == 5)
					{
						couter3 = 1;
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}

			}
			if (couter3 == 1)
			{
				Referee::ModeVicP2();
				Referee::VicNum = 1;
				break;
			}
		}
	}
}

//б����������½�����������
void Referee::P2VictoryJudgment4(ChessBoard Board1)
{
	int Num4 = 0;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				Num4++;
			}
		}
	}

	if (Num4 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
			for (int m = 1; m < 15;m++)
			{
				if (Board1.Board[k][m] == 10)
				{
					int couter1 = 1;
					for (int couter2 = 1;couter2 < 5;couter2++)
					{
						if (k + couter2 < 15 && m - couter2 > 0)
						{
							if (Board1.Board[k + couter2][m - couter2] == 10)
							{
								couter1++;
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
					if (couter1 == 5)
					{
						couter3 = 1;
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}

			}
			if (couter3 == 1)
			{
				Referee::ModeVicP2();
				Referee::VicNum = 1;
				break;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------




//��������Ƿ�ʤ���ж�����
void Referee::PCVictoryJudgment1(ChessBoard Board1)
{
	for (int i = 1; i < 15; i++)
	{
		int num1 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				num1++;
			}

		}
		if (num1 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[num1];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
				if (Board1.Board[i][k] == 10)
				{
					p[p1] = k;
					p1++;
				}
			}


			for (int m = 0; m < num1 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVicComputer();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
			delete[]p;

		}
	}
}

//��ֱ����������������ж�
void Referee::PCVictoryJudgment2(ChessBoard Board1)
{

	for (int i = 1; i < 15; i++)
	{
		int Num2 = 0;
		for (int j = 1; j < 15; j++)
		{
			if (Board1.Board[j][i] == 10)
			{
				Num2++;
			}

		}

		if (Num2 < 5)
		{
			continue;
		}
		else
		{
			int* p;
			p = new int[Num2];
			int p1 = 0;
			for (int k = 1; k < 15; k++)
			{
				if (Board1.Board[k][i] == 10)
				{
					p[p1] = k;
					p1++;
				}
			}


			for (int m = 0; m < Num2 - 4; m++)
			{
				int temp1 = m;
				int temp2 = m + 1;
				int Difference = abs(p[temp1] - p[temp2]);
				if (Difference == 1)
				{
					int n = m + 4;
					if (p[n] == p[m] + 4)
					{
						VicNum = 1;
						Referee::ModeVicComputer();
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
			delete[]p;
		}
	}
}

//б��������½�����������
void Referee::PCVictoryJudgment3(ChessBoard Board1)
{
	int Num3 = 0;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				Num3++;
			}
		}
	}
	if (Num3 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
			for (int m = 1; m < 15;m++)
			{
				if (Board1.Board[k][m] == 10)
				{
					int couter1 = 1;
					for (int couter2 = 1;couter2 < 5;couter2++)
					{
						if (k + couter2 < 15 && m + couter2 < 15)
						{
							if (Board1.Board[k + couter2][m + couter2] == 10)
							{
								couter1++;
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
					if (couter1 == 5)
					{
						couter3 = 1;
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}

			}
			if (couter3 == 1)
			{
				Referee::ModeVicComputer();
				Referee::VicNum = 1;
				break;
			}
		}
	}
}

//б����������½�����������
void Referee::PCVictoryJudgment4(ChessBoard Board1)
{
	int Num4 = 0;
	for (int i = 1; i < 15;i++)
	{
		for (int j = 1; j < 15;j++)
		{
			if (Board1.Board[i][j] == 10)
			{
				Num4++;
			}
		}
	}

	if (Num4 >= 5)
	{
		int couter3 = 0;
		for (int k = 1;k < 15;k++)
		{
			for (int m = 1; m < 15;m++)
			{
				if (Board1.Board[k][m] == 10)
				{
					int couter1 = 1;
					for (int couter2 = 1;couter2 < 5;couter2++)
					{
						if (k + couter2 < 15 && m - couter2 > 0)
						{
							if (Board1.Board[k + couter2][m - couter2] == 10)
							{
								couter1++;
							}
							else
							{
								break;
							}
						}
						else
						{
							break;
						}
					}
					if (couter1 == 5)
					{
						couter3 = 1;
						break;
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}

			}
			if (couter3 == 1)
			{
				Referee::ModeVicComputer();
				Referee::VicNum = 1;
				break;
			}
		}
	}
}



