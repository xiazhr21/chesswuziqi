#include "Referee.h"
#include "ChessBoard.h"
#include "player.h"
#include "Computer.h"


int Referee::VicNum = 0;

void Referee::Introduction()
{
	cout << "-----------" << "��������Ϸ  produced by Xia !!!" << "-----------" << endl;
}

void Referee::StartMenu()
{
	cout << "****************************" << endl;
	cout << "*******  1 �˻���ս  *******" << endl;
	cout << "*******  2 ���˶�ս  *******" << endl;
	cout << "*******  3 �˳���Ϸ  *******" << endl;
	cout << "****************************" << endl;

}

void Referee::Modejudgment()
{
	cout << "��ѡ����Ϸģʽ��" << endl;
	int select;

	cin >> select;
	system("cls");
	switch (select)
	{
	case 1:
		cout << "1 �˻���սģʽ" << endl;
		Referee::Mode1();
		break;
	case 2:
		cout << "2 ���˶�սģʽ" << endl;
		Referee::Mode2();
		break;
	case 3:
		Referee::Mode3();
		break;
	default:
		break;
	}
}