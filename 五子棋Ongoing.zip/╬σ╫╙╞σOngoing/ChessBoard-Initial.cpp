#include "ChessBoard.h"
#include<string>
#include "player.h"


int ChessBoard::Board[16][16] = {NULL};
int ChessBoard::BoardX = 0;
int ChessBoard::BoardY = 0;


//���̸���ֵ
void ChessBoard::InitialBoardValue()
{
	//�����Ͻ�
	for (int j = 1; j < 16; j++)
	{
		//���ϽǱ�
		if (j == 1)
		{
			Board[1][j] = 1;
		}
		//���½Ǳ�
		else if (j == 15)
		{
			Board[1][j] = 3;
		}
		//������߽�
		else
		{
			Board[1][j] = 2;
		}
	}
	//�����½�
	for (int j = 1; j < 16; j++)
	{
		if (j == 1)
		{
			Board[15][j] = 7;
		}
		else if (j == 15)
		{
			Board[15][j] = 9;
		}
		else
		{
			Board[15][j] = 8;
		}
	}

	for (int i = 2; i < 15; i++)
	{
		for (int j = 1; j < 16; j++)
		{
			if (j == 1)
			{
				Board[i][j] = 4;
			}
			else if (j == 15)
			{
				Board[i][j] = 6;
			}
			else
			{
				Board[i][j] = 5;
			}
		}

	}

}


